# Exercise: Area of Circle
radius = float (input ("Enter the Radius of Circle: "))
area = 3.14*(radius*radius)
print(f"The area of the circle is {area}")